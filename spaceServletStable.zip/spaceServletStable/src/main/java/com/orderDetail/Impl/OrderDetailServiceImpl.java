package com.orderDetail.Impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.orderMaster.model.OrderMasterDAO;
import com.orderMaster.model.OrderMasterDAOInterface;

public class OrderDetailServiceImpl {
	
	OrderMasterDAOInterface omi = new OrderMasterDAO();
	
//	@Override
//	public String submitOrder(List<Map<String, Object>> cart) {
//		
//		
//		Date date = new Date();
//
//		return null;
//	}
	
	
}
