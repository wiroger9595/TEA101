package com.orderDetail.Impl;

import java.util.List;
import java.util.Map;

public interface OrderDetailServiceInterface {

    String submitOrders(List<Map<String, Object>> cart);

}
