//package com.mailServlet.controller;
//
//import java.io.IOException;
//
//import javax.servlet.annotation.WebServlet;
//
//import Acme.Serve.servlet.ServletException;
//import Acme.Serve.servlet.http.HttpServlet;
//import Acme.Serve.servlet.http.HttpServletRequest;
//import Acme.Serve.servlet.http.HttpServletResponse;
//
////@WebServlet(name = "", urlPatterns = {"/MailDispatcherServlet"})
//public class MailDispatcherServlet extends HttpServlet {
//	
//	
//	
//	
//	protected void processRequest(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
//		res.setContentType("text/html;charset=UTF-8");
//		
//		String toEmail = req.getParameter("");
//		
//		
//	}
//	
//	@Override
//	public void service(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		
//	}
//}
