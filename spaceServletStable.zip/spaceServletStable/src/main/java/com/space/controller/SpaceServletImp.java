package com.space.controller;

import java.util.List;

import com.space.model.SpaceDAOInterface;
import com.space.model.SpaceVO;

public class SpaceServletImp implements SpaceDAOInterface{

	@Override
	public void insert(SpaceVO spaceVO) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(String spaceId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(SpaceVO spaceVO) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public SpaceVO selectOne(String spaceId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SpaceVO> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SpaceVO> queryByStartEnd(int start, int end) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SpaceVO querDetail(long spaceId) {
		// TODO Auto-generated method stub
		return null;
	}
	


}
